def matrix_multiply(A, B):
    # Check if matrices are multipliable
    if len(A[0]) != len(B):
        print("Error: Matrices A and B are not compatible for multiplication.")
        return None
    # Initialize the result matrix with zeros
    result = [[0 for _ in range(len(B[0]))] for _ in range(len(A))]
    # Perform matrix multiplication
    for i in range(len(A)):
        for j in range(len(B[0])):
            for k in range(len(B)):
                result[i][j] += A[i][k] * B[k][j]
    return result
# Get input for Matrix A
rows_A = int(input("Enter the number of rows for Matrix A: "))
cols_A = int(input("Enter the number of columns for Matrix A: "))
A = []
print("Enter elements for Matrix A:")
for i in range(rows_A):
    row = [int(input()) for _ in range(cols_A)]
    A.append(row)
# Get input for Matrix B
rows_B = int(input("Enter the number of rows for Matrix B: "))
cols_B = int(input("Enter the number of columns for Matrix B: "))
B = []
print("Enter elements for Matrix B:")
for i in range(rows_B):
    row = [int(input()) for _ in range(cols_B)]
    B.append(row)
# Call the matrix_multiply function and print the result
result = matrix_multiply(A, B)

if result is not None:
    print("Matrix A * Matrix B:")
    for row in result:
        print(row)
