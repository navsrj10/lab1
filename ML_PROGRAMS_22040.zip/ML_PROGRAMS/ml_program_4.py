def transpose_matrix(matrix):
    # Calculate the number of rows and columns in the original matrix
    rows = len(matrix)
    cols = len(matrix[0])
    # Initialize a new matrix with transposed dimensions
    transposed_matrix = [[0 for _ in range(rows)] for _ in range(cols)]
    # Populate the transposed matrix
    for i in range(rows):
        for j in range(cols):
            transposed_matrix[j][i] = matrix[i][j]
    return transposed_matrix
# Get input for the matrix
rows = int(input("Enter the number of rows: "))
cols = int(input("Enter the number of columns: "))
matrix = []
print("Enter elements for the matrix:")
for i in range(rows):
    row = [int(input()) for _ in range(cols)]
    matrix.append(row)
# Call the transpose_matrix function and print the result
transposed_result = transpose_matrix(matrix)
print("Original Matrix:")
for row in matrix:
    print(row)
print("\nTransposed Matrix:")
for row in transposed_result:
    print(row)
