def count_common_elements(list1, list2):
    common_elements = set(list1) & set(list2)
    return len(common_elements)
# Example lists
list1 = [1, 9, 6, 4, 5]
list2 = [6, 4, 5, 6, 9]
# Call the function and print the result
common_count = count_common_elements(list1, list2)
print("Number of common elements:", common_count)
